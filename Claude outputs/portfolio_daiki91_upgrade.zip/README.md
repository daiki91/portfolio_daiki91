# Portfolio — Bodian Arphan Kaback Junior

## Lancer le site

```bash
npm install
node server.js
```

Le portfolio est disponible sur `http://localhost:5000`. Le CV peut être consulté sur `http://localhost:5000/cv`, téléchargé en PDF ou quitté avec le lien de retour au portfolio.

La section « Rapports » du portfolio affiche automatiquement tous les documents PDF du dossier `rapport` (via la route `/api/rapports`) : il suffit d’y déposer un nouveau PDF pour qu’il apparaisse. Pour lui donner un titre et une description personnalisés, ajoutez une entrée dans `reportDetails` dans `cv_arphan.html` ; sinon, le titre est déduit du nom du fichier.

## Messages de contact

Le formulaire « Me contacter » envoie les messages à `POST /api/contact`. Ils sont enregistrés dans `.data/messages.json` (dossier non servi par le site et ignoré par Git).

Pour les consulter, définissez un jeton dans un fichier `.env` :

```
ADMIN_TOKEN=un-long-jeton-secret
```

puis ouvrez `http://localhost:5000/messages?token=un-long-jeton-secret`. Sans jeton, la lecture est refusée.

Si le site est ouvert sans le serveur (fichier local ou hébergement statique), le formulaire ouvre la messagerie du visiteur avec le message prérempli.

## Rapports et miniatures

Les miniatures des rapports sont dans `images/rapports/`. Pour un nouveau PDF, générez la première page en image (par exemple `pdftoppm -png -f 1 -l 1 -scale-to 900 rapport/mon-rapport.pdf images/rapports/mon-rapport`) et ajoutez `thumbnail: 'images/rapports/mon-rapport.webp'` dans `reportDetails`. Sans miniature, une vignette « PDF » s'affiche.

## Études de cas

Les études de cas (bouton « Étude de cas » sur chaque projet) reprennent le contenu des cartes. Pour ajouter la stack technique ou un résultat chiffré, complétez `stack` et `result` dans l'objet `caseStudies` de `cv_arphan.html`.
