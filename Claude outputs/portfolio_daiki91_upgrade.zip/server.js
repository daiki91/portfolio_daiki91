require("dotenv").config();

const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");

const app = express();

app.use(cors());
app.use(express.json({ limit: "20kb" }));

const RAPPORTS_DIR = path.join(__dirname, "rapport");
// Dossier commençant par un point : jamais servi par express.static (dotfiles ignorés)
const DATA_DIR = path.join(__dirname, ".data");
const MESSAGES_FILE = path.join(DATA_DIR, "messages.json");

// Lister tous les rapports PDF présents dans le dossier "rapport"
app.get("/api/rapports", async (req, res) => {
  try {
    const entries = await fs.promises.readdir(RAPPORTS_DIR, { withFileTypes: true });
    const pdfs = entries.filter(
      (entry) => entry.isFile() && path.extname(entry.name).toLowerCase() === ".pdf"
    );

    const rapports = await Promise.all(
      pdfs.map(async (entry) => {
        const stats = await fs.promises.stat(path.join(RAPPORTS_DIR, entry.name));
        return {
          fichier: entry.name,
          url: "rapport/" + encodeURIComponent(entry.name),
          taille: stats.size,
          modifie: stats.mtime
        };
      })
    );

    rapports.sort((a, b) => a.fichier.localeCompare(b.fichier, "fr"));
    res.json(rapports);
  } catch (err) {
    if (err.code === "ENOENT") {
      return res.json([]);
    }
    console.error("Lecture du dossier rapport impossible :", err);
    res.status(500).json({ error: "Impossible de lire le dossier des rapports" });
  }
});

// ---------- Messages de contact (enregistrés sur disque) ----------
async function readMessages() {
  try {
    return JSON.parse(await fs.promises.readFile(MESSAGES_FILE, "utf8"));
  } catch (err) {
    if (err.code === "ENOENT") return [];
    throw err;
  }
}

let writeQueue = Promise.resolve();
function saveMessage(message) {
  // Les écritures sont mises en file pour ne jamais perdre un message
  writeQueue = writeQueue.then(async () => {
    await fs.promises.mkdir(DATA_DIR, { recursive: true });
    const messages = await readMessages();
    messages.unshift(message);
    const tmp = MESSAGES_FILE + ".tmp";
    await fs.promises.writeFile(tmp, JSON.stringify(messages, null, 2), "utf8");
    await fs.promises.rename(tmp, MESSAGES_FILE);
  });
  return writeQueue;
}

// Limite simple : 5 messages par adresse IP toutes les 15 minutes
const RATE_WINDOW_MS = 15 * 60 * 1000;
const RATE_MAX = 5;
const recentByIp = new Map();
function isRateLimited(ip) {
  const now = Date.now();
  const hits = (recentByIp.get(ip) || []).filter((time) => now - time < RATE_WINDOW_MS);
  hits.push(now);
  recentByIp.set(ip, hits);
  return hits.length > RATE_MAX;
}

const clean = (value, max) => String(value || "").trim().slice(0, max);
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

async function handleContact(req, res) {
  const body = req.body || {};
  // Champ piège invisible : rempli uniquement par les robots
  if (clean(body.website, 200)) {
    return res.json({ success: true });
  }

  const name = clean(body.name, 80);
  const email = clean(body.email, 120);
  const content = clean(body.message || body.content, 2000);

  if (!content) {
    return res.status(400).json({ error: "Message vide" });
  }
  if (body.email !== undefined && (!name || !EMAIL_RE.test(email))) {
    return res.status(400).json({ error: "Nom ou e-mail invalide" });
  }
  if (isRateLimited(req.ip)) {
    return res.status(429).json({ error: "Trop de messages, réessayez plus tard" });
  }

  try {
    await saveMessage({ id: Date.now(), date: new Date().toISOString(), name, email, content });
    res.json({ success: true });
  } catch (err) {
    console.error("Enregistrement du message impossible :", err);
    res.status(500).json({ error: "Impossible d’enregistrer le message" });
  }
}

app.post("/api/contact", handleContact);
// Ancienne route conservée pour compatibilité
app.post("/messages", handleContact);

// Lecture des messages : protégée par le jeton ADMIN_TOKEN défini dans .env
app.get("/messages", async (req, res) => {
  const token = process.env.ADMIN_TOKEN;
  const provided = req.get("x-admin-token") || req.query.token;
  if (!token || provided !== token) {
    return res.status(401).json({ error: "Accès refusé" });
  }
  try {
    res.json(await readMessages());
  } catch (err) {
    console.error("Lecture des messages impossible :", err);
    res.status(500).json({ error: "Impossible de lire les messages" });
  }
});

// Servir les fichiers statiques (images, CV PDF, etc.)
app.use(express.static(path.join(__dirname)));

// Servir le fichier HTML du CV
app.get("/cv", (req, res) => {
  res.sendFile(path.join(__dirname, "cv", "cv_arphan.html"));
});

// Servir le portfolio à la racine
app.get("/", (req, res) => {
  res.sendFile(path.join(__dirname, "cv_arphan.html"));
});

const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log("Serveur lancé sur http://localhost:" + PORT);
});
